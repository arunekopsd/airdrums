/*
HMC5883L.cpp - Class file for the HMC5883L Triple Axis Magnetometer Arduino Library.
Copyright (C) 2016 Rajesh Kumar G <crimsonbloat@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the version 3 GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

 WARNING: THE HMC5883L IS NOT IDENTICAL TO THE HMC5883!
 Datasheet for HMC5883L:
 http://www51.honeywell.com/aero/common/documents/myaerospacecatalog-documents/Defense_Brochures-documents/HMC5883L_3-Axis_Digital_Compass_IC.pdf

*/
#include <Arduino.h>
#include <math.h>
#include "HMC5883L.h"

HMC5883L::HMC5883L(int sclPin, int sdaPin)
{
	m_i2c = SoftI2CMaster(sclPin, sdaPin);
	
	m_Reading.x = 0;
	m_Reading.y = 0;
	m_Reading.z = 0;
	
	m_PlanarHeading = 0;
}

int HMC5883L::Init()
{
	/* Set the module to 1x averaging and 15Hz measurement rate */
	m_i2c.beginTransmission(HMC5883L_Address);
	m_i2c.write(0x00);
	m_i2c.write(0x10);
          
	/* Set a gain of 5 */
	m_i2c.write(0x01);
	m_i2c.write(0xD0);
  
	m_i2c.endTransmission();
	
	return 0;
}

HMC5883LReading HMC5883L::GetReadings()
{
	return m_Reading;
}

float HMC5883L::GetPlanarHeading()
{
	return m_PlanarHeading;
}

int HMC5883L::Measure() 
{
	uint8_t rdy=0, buf[6];
	int i=0;
	
	m_i2c.beginTransmission(HMC5883L_Address);
    m_i2c.write(0x02);
    m_i2c.write(0x01);
    m_i2c.endTransmission();
    delay(8);

    while (!rdy) {
        m_i2c.beginTransmission(HMC5883L_Address);
        m_i2c.write(0x09);
        m_i2c.endTransmission();

        m_i2c.requestFrom(HMC5883L_Address);
        rdy = m_i2c.readLast();
        rdy = rdy & 0x01;
        if (!rdy) { delay(10); }
    }

    m_i2c.beginTransmission(HMC5883L_Address);
    m_i2c.write(0x03);
    m_i2c.endTransmission();  	
	
    m_i2c.requestFrom(HMC5883L_Address);      
    while(i<5)
    { 
       buf[i] = m_i2c.read();  // Read one byte
       i++;
    }    
    buf[i++] = m_i2c.readLast();	
	
    m_Reading.x = ((buf[0] << 8) | buf[1]);
    m_Reading.z = ((buf[2] << 8) | buf[3]);
    m_Reading.y = ((buf[4] << 8) | buf[5]);	
	
    float x0 = (float)m_Reading.x;
    float y0 = (float)m_Reading.y;
    float z0 = (float)m_Reading.z;

    double  x1, y1;
    if ( m_Reading.z != 0 ) {
        double t1 = x0*x0 + y0*y0;
        double t2 = t1 + z0 * z0;
        double P = sqrt(t1);
        double Q = sqrt(t2);
          
        double sinO = y0/P;
        double cosO = x0/P;
        double sinW = P/z0;
        double cosW = z0/Q;
        double xT   = z0 * sinW - P * cosW;
        
        x1   = xT * cosO;
        y1   = xT * sinO;
    } else {
        x1 = x0;
        y1 = y0;
    }      

    float heading = atan2(y1, x1);
    heading = heading * 180/M_PI;	
	
	m_PlanarHeading = heading;

	return 0;
}
