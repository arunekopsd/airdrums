S2MIDI: Open Source Serial to MIDI Converter for Windows

Version: 	1.0 - November 7, 2007
Version: 	1.1 - November 29, 2007 - Minor interface changes
					
Converts three byte NoteOn and CC MIDI messages from a serial port to a MIDI device driver. 

For more information see: 
http://memeteam.net/s2midi
