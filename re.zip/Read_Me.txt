

Before loading the HMC5883L example code, or even opening the arduino software, place the HMC5883L folder in your arduino library.

Mac   : In (home directory)/Documents/Arduino/libraries
PC    : My Documents -> Arduino -> libraries
Linux : (home directory)/sketchbook/libraries
